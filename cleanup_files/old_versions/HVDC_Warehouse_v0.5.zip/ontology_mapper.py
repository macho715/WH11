"""ontology_mapper.py – v0.3.1 (2025‑06‑24)
HVDC Warehouse / 물류 트랜잭션 DataFrame → RDF 트리플 변환기
---------------------------------------------------------
* 변경 사항
  - **hasAmount** 데이터타입 프로퍼티 정식 지원 (xsd:decimal)
  - 매핑 룰 기본값을 `mapping_rules_v2.5.json` 으로 업데이트
  - 컬럼명(`Amount`, `TOTAL`) → `hasAmount` 자동 매핑 로직 포함
  - 테스트를 위해 `main()` 데모 CLI 추가

사용 예시
~~~~~~~~
>>> import pandas as pd, ontology_mapper as om
>>> df = pd.read_excel('HVDC_WAREHOUSE.xlsx')
>>> g  = om.OntologyMapper().add_dataframe(df)
>>> g.serialize('warehouse.ttl', format='turtle')
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

import pandas as pd
from rdflib import Graph, Literal, Namespace, URIRef
from rdflib.namespace import RDF, XSD

# ---------------------------------------------------------------------------
# Constants & Helpers
# ---------------------------------------------------------------------------

_DEFAULT_RULE_FILE = Path(__file__).with_suffix('').with_name('mapping_rules_v2.5.json')

# 기본 데이터타입 매핑 (룰 파일에서 override 가능)
_FALLBACK_DTYPE: Dict[str, str] = {
    'string': 'string',
    'int': 'integer',
    'decimal': 'decimal',
    'date': 'date',
}

# ---------------------------------------------------------------------------
# Core Class
# ---------------------------------------------------------------------------

class OntologyMapper:
    """DataFrame → RDF 변환기.

    Parameters
    ----------
    mapping_path : str | Path, optional
        매핑 룰 JSON 경로. 생략 시 모듈과 동일 폴더의 *mapping_rules_v2.5.json* 사용.
    base_subject : str, default "TransportEvent"
        주어(Subject) URI 로컬 네임 접두사.
    """

    def __init__(self, mapping_path: str | Path | None = None, *, base_subject: str = 'TransportEvent') -> None:
        self.mapping_path = Path(mapping_path or _DEFAULT_RULE_FILE)
        self.base_subject = base_subject
        self._load_rules()
        self.graph = Graph()
        # Prefix 바인딩
        for prefix, ns in self.ns_map.items():
            self.graph.bind(prefix, ns)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _load_rules(self) -> None:
        if not self.mapping_path.exists():
            raise FileNotFoundError(f"Mapping rule file not found: {self.mapping_path}")

        rules = json.loads(self.mapping_path.read_text(encoding='utf-8'))

        self.ns_map: Dict[str, Namespace] = {pfx: Namespace(uri) for pfx, uri in rules['namespaces'].items()}
        self.field_map: Dict[str, str] = rules.get('field_map', {})
        # 데이터타입 프로퍼티 매핑 (property → dtype)
        self.dtype_map: Dict[str, str] = {
            **_FALLBACK_DTYPE,
            **rules.get('datatype_map', {})
        }
        # hasAmount가 누락된 경우 기본 decimal로 강제 추가
        self.dtype_map.setdefault('hasAmount', 'decimal')

        # Amount 계열 컬럼명 → hasAmount 매핑 보강
        self.field_map.setdefault('Amount', 'hasAmount')
        self.field_map.setdefault('TOTAL', 'hasAmount')

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def _to_literal(self, value: Any, dtype: str) -> Literal | None:
        """Python 값 → rdflib Literal 변환."""
        if pd.isna(value):  # type: ignore[attr-defined]
            return None

        dtype = dtype.lower()
        if dtype in ('decimal', 'float'):
            return Literal(float(value), datatype=XSD.decimal)
        if dtype in ('int', 'integer'):
            return Literal(int(value), datatype=XSD.integer)
        if dtype == 'date':
            # 문자열·Timestamp 모두 지원
            return Literal(str(value)[:10], datatype=XSD.date)
        # default: string
        return Literal(str(value))

    def add_dataframe(self, df: pd.DataFrame) -> Graph:
        """DataFrame 전 행을 RDF Graph 에 추가하여 반환."""
        ex = self.ns_map['ex']  # type: ignore[index]

        for idx, row in df.iterrows():
            subj = URIRef(f"{ex}{self.base_subject}_{idx+1:06}")
            self.graph.add((subj, RDF.type, ex.TransportEvent))  # 타입 지정

            for col_name, prop in self.field_map.items():
                if col_name not in row or pd.isna(row[col_name]):
                    continue
                dtype = self.dtype_map.get(prop, 'string')
                lit = self._to_literal(row[col_name], dtype)
                if lit is not None:
                    self.graph.add((subj, ex[prop], lit))

        return self.graph

    # ------------------------------------------------------------------
    # CLI (quick demo)
    # ------------------------------------------------------------------

    @staticmethod
    def _cli() -> None:  # pragma: no cover
        import argparse, sys
        parser = argparse.ArgumentParser(description='HVDC Warehouse → RDF Turtle 변환기')
        parser.add_argument('excel', help='원본 Excel/XLSX 파일')
        parser.add_argument('-o', '--output', default='warehouse.ttl', help='결과 Turtle 파일')
        args = parser.parse_args()

        import pandas as pd
        df = pd.read_excel(args.excel)
        g = OntologyMapper().add_dataframe(df)
        g.serialize(destination=args.output, format='turtle')
        print(f"✔ RDF saved → {args.output}")

# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

if __name__ == '__main__':  # pragma: no cover
    OntologyMapper._cli() 