"""excel_reporter.py – v0.5 (2025‑06‑24)

HVDC Warehouse 월별 재무·재고 리포트 생성기
=========================================

* **신규 기능**
  1. `generate_financial_report(df, output_path)` – Billing month × StorageType 피벗으로 **Total_Amount** 집계 후 Excel 저장.
  2. `generate_full_dashboard(raw_df, output_path)` – 기존 KPI 시트 + FinancialSummary 시트 결합.
  3. 자동 스타일링: 금액(콤마·소수점 2자리), Conditional Formatting(최대값 녹색 → 최소값 빨강) 적용.

Dependencies
------------
- pandas ≥ 2.0
- xlsxwriter (ExcelWriter backend)

사용 예시
~~~~~~~~
>>> import pandas as pd, excel_reporter as xr, warehouse_loader as wl, inventory_engine as ie
>>> raw_df = wl.load_hvdc_warehouse_file("HVDC_WAREHOUSE_Q1.xlsx")
>>> xr.generate_full_dashboard(raw_df, "warehouse_fin_report.xlsx")
"""
from __future__ import annotations

import pandas as pd
from pathlib import Path

from core.inventory_engine import InventoryEngine

__all__ = [
    "generate_financial_report",
    "generate_full_dashboard",
]


def _style_worksheet(ws, max_row: int, max_col: int):
    """Apply basic styles & conditional formatting to a worksheet."""
    # Header bold
    header_format = ws.book.add_format({"bold": True, "bg_color": "#D9E1F2"})
    ws.set_row(0, None, header_format)

    # Numbers with comma & 2 decimals
    num_format = ws.book.add_format({"num_format": "#,##0.00"})
    ws.set_column(1, max_col, 18, num_format)  # skip first column (BillingMonth str)

    # Conditional formatting across data range
    ws.conditional_format(1, 1, max_row, max_col, {
        "type": "3_color_scale",
        "min_color": "#F8696B",
        "mid_color": "#FFEB84",
        "max_color": "#63BE7B",
    })


def generate_financial_report(df: pd.DataFrame, output_path: str | Path = "warehouse_fin_report.xlsx") -> Path:
    """Billing month × StorageType pivot with Total_Amount sums → Excel sheet.

    Parameters
    ----------
    df : pd.DataFrame
        Raw warehouse DataFrame containing at minimum the columns
        [`Billing month`, `Category` or `hasStorageType`, `Amount` or `Total_Amount`].
    output_path : str | Path
        Target Excel file (will be created/overwritten).

    Returns
    -------
    Path
        Path to the generated Excel file.
    """
    output_path = Path(output_path)

    # Ensure correct dtype
    df = df.copy()
    df["BillingMonth"] = pd.to_datetime(df["Billing month"], errors="coerce").dt.to_period("M")
    amount_col = "Amount" if "Amount" in df.columns else "Total_Amount"

    pivot = pd.pivot_table(
        df,
        values=amount_col,
        index="BillingMonth",
        columns="Category" if "Category" in df.columns else "hasStorageType",
        aggfunc="sum",
        fill_value=0.0,
    ).sort_index()

    # Save to Excel
    with pd.ExcelWriter(output_path, engine="xlsxwriter") as writer:
        pivot.to_excel(writer, sheet_name="FinancialSummary")
        ws = writer.book.worksheets()[0]
        max_row, max_col = pivot.shape
        _style_worksheet(ws, max_row + 1, max_col)  # + header row

    return output_path


def generate_full_dashboard(raw_df: pd.DataFrame, output_path: str | Path = "warehouse_fin_report.xlsx") -> Path:
    """Create full dashboard: KPI + FinancialSummary."""
    output_path = Path(output_path)

    engine = InventoryEngine(raw_df)
    monthly_summary = engine.calculate_monthly_summary()
    financial_pivot_path = generate_financial_report(raw_df, output_path)

    # Append the KPI sheet in same file
    with pd.ExcelWriter(financial_pivot_path, engine="xlsxwriter", mode="a") as writer:
        monthly_summary.to_excel(writer, sheet_name="KPI_Summary", index=False)
        # Style KPI_Summary sheet basic number format
        ws = writer.book.worksheets()[-1]
        num_format = writer.book.add_format({"num_format": "#,##0.00"})
        ws.set_column(0, monthly_summary.shape[1] - 1, 16, num_format)

    return financial_pivot_path


if __name__ == "__main__":
    import argparse
    from warehouse_loader import load_hvdc_warehouse_file

    parser = argparse.ArgumentParser(description="Generate HVDC Warehouse financial report")
    parser.add_argument("excel", help="Raw HVDC Warehouse Excel file path")
    parser.add_argument("--out", default="warehouse_fin_report.xlsx", help="Output Excel file")
    args = parser.parse_args()

    raw_df = load_hvdc_warehouse_file(args.excel)
    path = generate_full_dashboard(raw_df, args.out)
    print(f"✅ Financial report created: {path}") 